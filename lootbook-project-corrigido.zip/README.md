# LOOTBOOK - Instruções de Instalação

Este é um projeto front-end baseado no layout do Figma fornecido. O projeto foi desenvolvido utilizando Next.js, TypeScript, Tailwind CSS, Framer Motion, Swiper e Color-thief-ts.

## Instalação

1. Descompacte o arquivo ZIP
2. Navegue até a pasta do projeto
3. Instale as dependências:

```bash
npm install
```

4. **IMPORTANTE**: Limpe o cache do Next.js antes de executar:

```bash
npm run clean
# ou manualmente
rm -rf .next
```

5. Execute o projeto:

```bash
npm run dev
```

6. Acesse o projeto no navegador: [http://localhost:3000](http://localhost:3000)

## Solução de Problemas

Se encontrar erros ao executar o projeto:

1. Certifique-se de que todas as dependências foram instaladas corretamente:
```bash
rm -rf node_modules
npm install
```

2. Verifique se está usando Node.js versão 18 ou superior

3. Se o erro persistir, tente:
```bash
npm cache clean --force
npm install
npm run dev
```

## Funcionalidades Implementadas

- Carrossel de personagens com efeito de cards
- Extração de cores dominantes das imagens para criar sombras dinâmicas
- Animações suaves de transição entre componentes
- Layout responsivo
- Navegação entre abas (Recent, Favorites, Archived)
- Barra de navegação inferior
- Cabeçalho com logo e perfil

## Tecnologias Utilizadas

- Next.js
- TypeScript
- Tailwind CSS
- Framer Motion
- Swiper
- Color-thief-ts
- React Icons
