import React from 'react';
import { motion } from 'framer-motion';
import { FiHome, FiCompass, FiBookmark, FiUser } from 'react-icons/fi';

interface BottomNavProps {}

const BottomNav: React.FC<BottomNavProps> = () => {
  const [activeTab, setActiveTab] = React.useState('home');
  
  const navItems = [
    { id: 'home', icon: FiHome },
    { id: 'discover', icon: FiCompass },
    { id: 'bookmarks', icon: FiBookmark },
    { id: 'profile', icon: FiUser },
  ];
  
  return (
    <motion.div 
      className="fixed bottom-0 left-0 right-0 bg-gray-900/80 backdrop-blur-lg border-t border-gray-800 py-3 px-6"
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ delay: 0.5, duration: 0.5 }}
    >
      <div className="flex justify-between items-center max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <motion.button
              key={item.id}
              className={`p-3 rounded-full ${
                activeTab === item.id ? 'text-teal-400' : 'text-gray-500'
              }`}
              whileHover={{ y: -5 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setActiveTab(item.id)}
            >
              <Icon size={20} />
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );
};

export default BottomNav;
