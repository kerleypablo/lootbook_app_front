import React from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';

interface HeaderProps {
  profileName: string;
  profileImage: string;
}

const Header: React.FC<HeaderProps> = ({ profileName, profileImage }) => {
  return (
    <header className="w-full flex justify-between items-center p-4">
      <div className="flex items-center">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-2xl font-bold">
            <span className="text-white">LOOT</span>
            <span className="text-teal-400">BOOK</span>
          </h1>
        </motion.div>
      </div>
      
      <div className="flex items-center gap-2">
        <div className="text-right mr-2">
          <p className="text-sm text-gray-400">Profile</p>
          <p className="text-sm font-medium">{profileName}</p>
        </div>
        <motion.div 
          className="w-10 h-10 rounded-full overflow-hidden"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Image 
            src={profileImage || '/images/default-avatar.png'} 
            alt="Profile" 
            width={40} 
            height={40}
            className="object-cover"
          />
        </motion.div>
      </div>
    </header>
  );
};

export default Header;
