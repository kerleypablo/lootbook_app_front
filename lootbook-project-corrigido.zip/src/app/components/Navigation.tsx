import React from 'react';
import { motion } from 'framer-motion';
import { FiSearch, FiSettings } from 'react-icons/fi';

interface NavigationProps {}

const Navigation: React.FC<NavigationProps> = () => {
  const [activeTab, setActiveTab] = React.useState('Recent');
  
  const tabs = ['Recent', 'Favorites', 'Archived'];
  
  return (
    <div className="w-full space-y-4">
      <div className="relative">
        <input
          type="text"
          placeholder="Search"
          className="w-full bg-gray-800/50 rounded-xl py-3 px-10 text-sm text-gray-300 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500/50"
        />
        <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
      </div>
      
      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          {tabs.map((tab) => (
            <button
              key={tab}
              className={`relative px-1 py-2 text-sm font-medium ${
                activeTab === tab ? 'text-white' : 'text-gray-500'
              }`}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
              {activeTab === tab && (
                <motion.div
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-teal-400"
                  layoutId="activeTab"
                  initial={false}
                />
              )}
            </button>
          ))}
        </div>
        
        <motion.button
          whileHover={{ rotate: 45 }}
          whileTap={{ scale: 0.9 }}
          className="p-2 rounded-full text-gray-500 hover:text-white hover:bg-gray-800/50"
        >
          <FiSettings />
        </motion.button>
      </div>
    </div>
  );
};

export default Navigation;
