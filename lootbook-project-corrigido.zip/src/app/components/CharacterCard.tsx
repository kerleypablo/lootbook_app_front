import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { getDominantColor, getShadowStyle } from '../utils/getDominantColor';
import { FaArrowRight } from 'react-icons/fa';

interface CharacterCardProps {
  image: string;
  name: string;
  race: string;
  class: string;
  level: number;
}

const CharacterCard: React.FC<CharacterCardProps> = ({ 
  image, 
  name, 
  race, 
  class: characterClass, 
  level 
}) => {
  const [dominantColor, setDominantColor] = useState<string>('rgba(128, 0, 128, 0.5)');
  const [shadowStyle, setShadowStyle] = useState<string>('');

  useEffect(() => {
    const loadDominantColor = async () => {
      const color = await getDominantColor(image);
      setDominantColor(color);
      setShadowStyle(getShadowStyle(color));
    };

    loadDominantColor();
  }, [image]);

  return (
    <motion.div 
      className="relative w-full max-w-sm mx-auto rounded-3xl overflow-hidden"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      style={{ 
        boxShadow: shadowStyle,
      }}
    >
      <div className="relative w-full h-[500px]">
        <Image 
          src={image} 
          alt={name}
          fill
          style={{ objectFit: 'cover' }}
          className="rounded-3xl"
          priority
        />
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent text-white">
        <h2 className="text-2xl font-bold">{name}</h2>
        <p className="text-sm opacity-80">{race} - {characterClass} - Level {level}</p>
      </div>
      
      <motion.button 
        className="absolute bottom-6 right-6 bg-white/20 backdrop-blur-sm p-2 rounded-full"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <FaArrowRight className="text-white" />
      </motion.button>
    </motion.div>
  );
};

export default CharacterCard;
