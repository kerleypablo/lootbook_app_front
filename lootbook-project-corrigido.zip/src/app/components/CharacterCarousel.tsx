import React, { useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { EffectCards, Navigation, Pagination } from 'swiper/modules';
import CharacterCard from './CharacterCard';
import { motion, AnimatePresence } from 'framer-motion';

// Importações de estilos do Swiper
import 'swiper/css';
import 'swiper/css/effect-cards';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

interface Character {
  id: number;
  name: string;
  race: string;
  class: string;
  level: number;
  image: string;
}

const characters: Character[] = [
  {
    id: 1,
    name: 'Charles Lourance',
    race: 'Human',
    class: 'Warlock',
    level: 8,
    image: '/images/charles_lourance.png',
  },
  // Outros personagens seriam adicionados aqui
];

const CharacterCarousel: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className="w-full max-w-md mx-auto">
      <Swiper
        effect={'cards'}
        grabCursor={true}
        modules={[EffectCards, Navigation, Pagination]}
        className="character-swiper"
        onSlideChange={(swiper) => setActiveIndex(swiper.activeIndex)}
        pagination={{
          clickable: true,
          dynamicBullets: true,
        }}
      >
        <AnimatePresence mode="wait">
          {characters.map((character) => (
            <SwiperSlide key={character.id}>
              <CharacterCard
                image={character.image}
                name={character.name}
                race={character.race}
                class={character.class}
                level={character.level}
              />
            </SwiperSlide>
          ))}
        </AnimatePresence>
      </Swiper>
      
      <div className="flex justify-center mt-4 space-x-2">
        {characters.map((_, index) => (
          <motion.div
            key={index}
            className={`h-2 rounded-full ${
              index === activeIndex ? 'w-6 bg-teal-400' : 'w-2 bg-gray-400'
            }`}
            animate={{
              width: index === activeIndex ? 24 : 8,
              backgroundColor: index === activeIndex ? '#2DD4BF' : '#9CA3AF',
            }}
            transition={{ duration: 0.3 }}
          />
        ))}
      </div>
    </div>
  );
};

export default CharacterCarousel;
